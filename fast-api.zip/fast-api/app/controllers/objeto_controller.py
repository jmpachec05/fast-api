# controllers/objeto_controller.py
from fastapi import HTTPException
from fastapi.encoders import jsonable_encoder
import mysql.connector
from config.db_config import get_db_connection

class ObjetoController:
    def obtener_objetos(self):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM objeto")
            result = cursor.fetchall()
            payload = []
            
            for data in result:
                content = {
                    'id': int(data[0]),
                    'nombre': data[1],
                    'tipo_objeto': data[2],
                    'estado': data[3],
                    'fecha': data[4],
                    'usuario_id': int(data[5])
                }
                payload.append(content)

            json_data = jsonable_encoder(payload)
            return {"resultado": json_data}
        
        except mysql.connector.Error as err:
            raise HTTPException(status_code=500, detail=str(err))
        
        finally:
            if conn:
                conn.close()
