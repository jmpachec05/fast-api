import mysql.connector
from fastapi import HTTPException
from config.db_config import get_db_connection
from models.permisos_model import Permisos
from fastapi.encoders import jsonable_encoder

class PermisosController:

    def crear_permiso(self, permiso: Permisos):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO permisos (rol_id, permiso) VALUES (%s, %s)",
                (permiso.rol_id, permiso.permiso)
            )
            conn.commit()
            return {"resultado": "Permiso creado"}
        except mysql.connector.Error as err:
            conn.rollback()
            raise HTTPException(status_code=500, detail="Error al crear permiso")
        finally:
            conn.close()

    def obtener_permiso(self, permiso_id: int):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM permisos WHERE id = %s", (permiso_id,))
            result = cursor.fetchone()

            if result:
                return {
                    'id': result[0],
                    'rol_id': result[1],
                    'permiso': result[2],
                }
            else:
                raise HTTPException(status_code=404, detail="Permiso no encontrado")
        except mysql.connector.Error as err:
            raise HTTPException(status_code=500, detail="Error al obtener permiso")
        finally:
            conn.close()

    def obtener_permisos_todos(self):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM permisos")
            result = cursor.fetchall()
            return [
                {
                    'id': data[0],
                    'rol_id': data[1],
                    'permiso': data[2],
                }
                for data in result
            ]
        except mysql.connector.Error as err:
            raise HTTPException(status_code=500, detail="Error al obtener permisos")
        finally:
            conn.close()

    def actualizar_permiso(self, permiso_id: int, permiso: Permisos):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE permisos SET rol_id=%s, permiso=%s WHERE id=%s",
                (permiso.rol_id, permiso.permiso, permiso_id)
            )
            conn.commit()
            if cursor.rowcount == 0:
                raise HTTPException(status_code=404, detail="Permiso no encontrado")
            return {"resultado": "Permiso actualizado"}
        except mysql.connector.Error as err:
            conn.rollback()
            raise HTTPException(status_code=500, detail="Error al actualizar permiso")
        finally:
            conn.close()

    def eliminar_permiso(self, permiso_id: int):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("DELETE FROM permisos WHERE id = %s", (permiso_id,))
            conn.commit()
            if cursor.rowcount == 0:
                raise HTTPException(status_code=404, detail="Permiso no encontrado")
            return {"resultado": "Permiso eliminado"}
        except mysql.connector.Error as err:
            conn.rollback()
            raise HTTPException(status_code=500, detail="Error al eliminar permiso")
        finally:
            conn.close()
