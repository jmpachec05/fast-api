import mysql.connector
from fastapi import HTTPException
from config.db_config import get_db_connection
from models.notificaciones_model import Notificaciones
from fastapi.encoders import jsonable_encoder

class NotificacionesController:

    def crear_notificacion(self, notificacion: Notificaciones):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO notificaciones (user_id, incidencia_id, mensaje, leido) VALUES (%s, %s, %s, %s)",
                (notificacion.user_id, notificacion.incidencia_id, notificacion.mensaje, notificacion.leido)
            )
            conn.commit()
            return {"resultado": "Notificación creada"}
        except mysql.connector.Error as err:
            conn.rollback()
            raise HTTPException(status_code=500, detail="Error al crear notificación")
        finally:
            conn.close()

    def obtener_notificacion(self, notificacion_id: int):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM notificaciones WHERE id = %s", (notificacion_id,))
            result = cursor.fetchone()

            if result:
                return {
                    'id': result[0],
                    'user_id': result[1],
                    'incidencia_id': result[2],
                    'mensaje': result[3],
                    'leido': bool(result[4]),
                    'fecha': result[5],
                }
            else:
                raise HTTPException(status_code=404, detail="Notificación no encontrada")
        except mysql.connector.Error as err:
            raise HTTPException(status_code=500, detail="Error al obtener notificación")
        finally:
            conn.close()

    def obtener_notificaciones_todas(self):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM notificaciones")
            result = cursor.fetchall()
            return [
                {
                    'id': data[0],
                    'user_id': data[1],
                    'incidencia_id': data[2],
                    'mensaje': data[3],
                    'leido': bool(data[4]),
                    'fecha': data[5],
                }
                for data in result
            ]
        except mysql.connector.Error as err:
            raise HTTPException(status_code=500, detail="Error al obtener notificaciones")
        finally:
            conn.close()

    def actualizar_notificacion(self, notificacion_id: int, notificacion: Notificaciones):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE notificaciones SET user_id=%s, incidencia_id=%s, mensaje=%s, leido=%s WHERE id=%s",
                (notificacion.user_id, notificacion.incidencia_id, notificacion.mensaje, notificacion.leido, notificacion_id)
            )
            conn.commit()
            if cursor.rowcount == 0:
                raise HTTPException(status_code=404, detail="Notificación no encontrada")
            return {"resultado": "Notificación actualizada"}
        except mysql.connector.Error as err:
            conn.rollback()
            raise HTTPException(status_code=500, detail="Error al actualizar notificación")
        finally:
            conn.close()

    def eliminar_notificacion(self, notificacion_id: int):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("DELETE FROM notificaciones WHERE id = %s", (notificacion_id,))
            conn.commit()
            if cursor.rowcount == 0:
                raise HTTPException(status_code=404, detail="Notificación no encontrada")
            return {"resultado": "Notificación eliminada"}
        except mysql.connector.Error as err:
            conn.rollback()
            raise HTTPException(status_code=500, detail="Error al eliminar notificación")
        finally:
            conn.close()
