import mysql.connector
from fastapi import HTTPException
from config.db_config import get_db_connection
from models.knowledge_base_model import KnowledgeBase
from fastapi.encoders import jsonable_encoder

class KnowledgeBaseController:

    def crear_articulo(self, articulo: KnowledgeBase):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO knowledge_base (titulo, contenido, categoria) VALUES (%s, %s, %s)",
                (articulo.titulo, articulo.contenido, articulo.categoria)
            )
            conn.commit()
            return {"resultado": "Artículo ingresado"}
        except mysql.connector.Error as err:
            conn.rollback()
            raise HTTPException(status_code=500, detail="Error al insertar artículo")
        finally:
            conn.close()

    def obtener_articulo(self, articulo_id: int):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM knowledge_base WHERE id = %s", (articulo_id,))
            result = cursor.fetchone()

            if result:
                return {
                    'id': result[0],
                    'titulo': result[1],
                    'contenido': result[2],
                    'categoria': result[3],
                    'fecha_publicacion': result[4],
                }
            else:
                raise HTTPException(status_code=404, detail="Artículo no encontrado")
        except mysql.connector.Error as err:
            raise HTTPException(status_code=500, detail="Error al obtener artículo")
        finally:
            conn.close()

    def obtener_articulos(self):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM knowledge_base")
            result = cursor.fetchall()
            return [
                {
                    'id': data[0],
                    'titulo': data[1],
                    'contenido': data[2],
                    'categoria': data[3],
                    'fecha_publicacion': data[4],
                }
                for data in result
            ]
        except mysql.connector.Error as err:
            raise HTTPException(status_code=500, detail="Error al obtener artículos")
        finally:
            conn.close()

    def actualizar_articulo(self, articulo_id: int, articulo: KnowledgeBase):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE knowledge_base SET titulo=%s, contenido=%s, categoria=%s WHERE id=%s",
                (articulo.titulo, articulo.contenido, articulo.categoria, articulo_id)
            )
            conn.commit()
            if cursor.rowcount == 0:
                raise HTTPException(status_code=404, detail="Artículo no encontrado")
            return {"resultado": "Artículo actualizado"}
        except mysql.connector.Error as err:
            conn.rollback()
            raise HTTPException(status_code=500, detail="Error al actualizar artículo")
        finally:
            conn.close()

    def eliminar_articulo(self, articulo_id: int):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("DELETE FROM knowledge_base WHERE id = %s", (articulo_id,))
            conn.commit()
            if cursor.rowcount == 0:
                raise HTTPException(status_code=404, detail="Artículo no encontrado")
            return {"resultado": "Artículo eliminado"}
        except mysql.connector.Error as err:
            conn.rollback()
            raise HTTPException(status_code=500, detail="Error al eliminar artículo")
        finally:
            conn.close()
