import mysql.connector
from fastapi import HTTPException
from config.db_config import get_db_connection
from models.satisfaccion_model import Satisfaccion

class SatisfaccionController:

    def crear_satisfaccion(self, satisfaccion: Satisfaccion):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO satisfaccion (user_id, incidencia_id, calificacion, feedback) VALUES (%s, %s, %s, %s)",
                (satisfaccion.user_id, satisfaccion.incidencia_id, satisfaccion.calificacion, satisfaccion.feedback)
            )
            conn.commit()
            return {"resultado": "Satisfacción creada"}
        except mysql.connector.Error as err:
            conn.rollback()
            raise HTTPException(status_code=500, detail="Error al crear satisfacción")
        finally:
            conn.close()

    def obtener_satisfaccion(self, satisfaccion_id: int):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM satisfaccion WHERE id = %s", (satisfaccion_id,))
            result = cursor.fetchone()

            if result:
                return {
                    'id': result[0],
                    'user_id': result[1],
                    'incidencia_id': result[2],
                    'calificacion': result[3],
                    'feedback': result[4],
                }
            else:
                raise HTTPException(status_code=404, detail="Satisfacción no encontrada")
        except mysql.connector.Error as err:
            raise HTTPException(status_code=500, detail="Error al obtener satisfacción")
        finally:
            conn.close()

    def obtener_satisfacciones_todas(self):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM satisfaccion")
            result = cursor.fetchall()
            return [
                {
                    'id': data[0],
                    'user_id': data[1],
                    'incidencia_id': data[2],
                    'calificacion': data[3],
                    'feedback': data[4],
                }
                for data in result
            ]
        except mysql.connector.Error as err:
            raise HTTPException(status_code=500, detail="Error al obtener satisfacciones")
        finally:
            conn.close()

    def actualizar_satisfaccion(self, satisfaccion_id: int, satisfaccion: Satisfaccion):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE satisfaccion SET user_id=%s, incidencia_id=%s, calificacion=%s, feedback=%s WHERE id=%s",
                (satisfaccion.user_id, satisfaccion.incidencia_id, satisfaccion.calificacion, satisfaccion.feedback, satisfaccion_id)
            )
            conn.commit()
            if cursor.rowcount == 0:
                raise HTTPException(status_code=404, detail="Satisfacción no encontrada")
            return {"resultado": "Satisfacción actualizada"}
        except mysql.connector.Error as err:
            conn.rollback()
            raise HTTPException(status_code=500, detail="Error al actualizar satisfacción")
        finally:
            conn.close()

    def eliminar_satisfaccion(self, satisfaccion_id: int):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("DELETE FROM satisfaccion WHERE id = %s", (satisfaccion_id,))
            conn.commit()
            if cursor.rowcount == 0:
                raise HTTPException(status_code=404, detail="Satisfacción no encontrada")
            return {"resultado": "Satisfacción eliminada"}
        except mysql.connector.Error as err:
            conn.rollback()
            raise HTTPException(status_code=500, detail="Error al eliminar satisfacción")
        finally:
            conn.close()
