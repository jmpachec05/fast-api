import mysql.connector
from fastapi import HTTPException
from config.db_config import get_db_connection
from models.respuestas_model import Respuestas

class RespuestasController:

    def crear_respuesta(self, respuesta: Respuestas):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO respuestas (pregunta_clave, respuesta) VALUES (%s, %s)",
                (respuesta.pregunta_clave, respuesta.respuesta)
            )
            conn.commit()
            return {"resultado": "Respuesta creada"}
        except mysql.connector.Error as err:
            conn.rollback()
            raise HTTPException(status_code=500, detail="Error al crear respuesta")
        finally:
            conn.close()

    def obtener_respuesta(self, respuesta_id: int):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM respuestas WHERE id = %s", (respuesta_id,))
            result = cursor.fetchone()

            if result:
                return {
                    'id': result[0],
                    'pregunta_clave': result[1],
                    'respuesta': result[2],
                }
            else:
                raise HTTPException(status_code=404, detail="Respuesta no encontrada")
        except mysql.connector.Error as err:
            raise HTTPException(status_code=500, detail="Error al obtener respuesta")
        finally:
            conn.close()

    def obtener_respuestas_todas(self):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM respuestas")
            result = cursor.fetchall()
            return [
                {
                    'id': data[0],
                    'pregunta_clave': data[1],
                    'respuesta': data[2],
                }
                for data in result
            ]
        except mysql.connector.Error as err:
            raise HTTPException(status_code=500, detail="Error al obtener respuestas")
        finally:
            conn.close()

    def actualizar_respuesta(self, respuesta_id: int, respuesta: Respuestas):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE respuestas SET pregunta_clave=%s, respuesta=%s WHERE id=%s",
                (respuesta.pregunta_clave, respuesta.respuesta, respuesta_id)
            )
            conn.commit()
            if cursor.rowcount == 0:
                raise HTTPException(status_code=404, detail="Respuesta no encontrada")
            return {"resultado": "Respuesta actualizada"}
        except mysql.connector.Error as err:
            conn.rollback()
            raise HTTPException(status_code=500, detail="Error al actualizar respuesta")
        finally:
            conn.close()

    def eliminar_respuesta(self, respuesta_id: int):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("DELETE FROM respuestas WHERE id = %s", (respuesta_id,))
            conn.commit()
            if cursor.rowcount == 0:
                raise HTTPException(status_code=404, detail="Respuesta no encontrada")
            return {"resultado": "Respuesta eliminada"}
        except mysql.connector.Error as err:
            conn.rollback()
            raise HTTPException(status_code=500, detail="Error al eliminar respuesta")
        finally:
            conn.close()
