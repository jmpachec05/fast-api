import mysql.connector
from fastapi import HTTPException
from config.db_config import get_db_connection
from models.atributo_usuario_model import AtributoUsuario
from fastapi.encoders import jsonable_encoder

class AtributoUsuarioController:

    def crear_atributo_usuario(self, atributo_usuario: AtributoUsuario):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO atributo_usuario (id_usuario, id_atributo, valor_atributo, estado) VALUES (%s, %s, %s, %s)",
                (atributo_usuario.id_usuario, atributo_usuario.id_atributo, atributo_usuario.valor_atributo, atributo_usuario.estado)
            )
            conn.commit()
            return {"resultado": "Atributo Usuario ingresado"}
        except mysql.connector.Error as err:
            conn.rollback()
            raise HTTPException(status_code=500, detail="Error al insertar atributo usuario")
        finally:
            conn.close()

    def obtener_atributo_usuario(self, atributo_usuario_id: int):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM atributo_usuario WHERE id = %s", (atributo_usuario_id,))
            result = cursor.fetchone()

            if result:
                return {
                    'id': result[0],
                    'id_usuario': result[1],
                    'id_atributo': result[2],
                    'valor_atributo': result[3],
                    'estado': result[4],
                    'fecha_creacion': result[5],
                    'fecha_actualizacion': result[6],
                }
            else:
                raise HTTPException(status_code=404, detail="Atributo Usuario no encontrado")
        except mysql.connector.Error as err:
            raise HTTPException(status_code=500, detail="Error al obtener atributo usuario")
        finally:
            conn.close()

    def obtener_atributos_usuarios(self):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM atributo_usuario")
            result = cursor.fetchall()
            return [
                {
                    'id': data[0],
                    'id_usuario': data[1],
                    'id_atributo': data[2],
                    'valor_atributo': data[3],
                    'estado': data[4],
                    'fecha_creacion': data[5],
                    'fecha_actualizacion': data[6],
                }
                for data in result
            ]
        except mysql.connector.Error as err:
            raise HTTPException(status_code=500, detail="Error al obtener atributos usuarios")
        finally:
            conn.close()

    def actualizar_atributo_usuario(self, atributo_usuario_id: int, atributo_usuario: AtributoUsuario):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE atributo_usuario SET id_usuario=%s, id_atributo=%s, valor_atributo=%s, estado=%s WHERE id=%s",
                (atributo_usuario.id_usuario, atributo_usuario.id_atributo, atributo_usuario.valor_atributo, atributo_usuario.estado, atributo_usuario_id)
            )
            conn.commit()
            if cursor.rowcount == 0:
                raise HTTPException(status_code=404, detail="Atributo Usuario no encontrado")
            return {"resultado": "Atributo Usuario actualizado"}
        except mysql.connector.Error as err:
            conn.rollback()
            raise HTTPException(status_code=500, detail="Error al actualizar atributo usuario")
        finally:
            conn.close()

    def eliminar_atributo_usuario(self, atributo_usuario_id: int):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("DELETE FROM atributo_usuario WHERE id = %s", (atributo_usuario_id,))
            conn.commit()
            if cursor.rowcount == 0:
                raise HTTPException(status_code=404, detail="Atributo Usuario no encontrado")
            return {"resultado": "Atributo Usuario eliminado"}
        except mysql.connector.Error as err:
            conn.rollback()
            raise HTTPException(status_code=500, detail="Error al eliminar atributo usuario")
        finally:
            conn.close()
