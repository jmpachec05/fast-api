import mysql.connector
from fastapi import HTTPException
from config.db_config import get_db_connection
from models.conversaciones_model import Conversacion
from fastapi.encoders import jsonable_encoder

class ConversacionesController:

    def crear_conversacion(self, conversacion: Conversacion):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO conversaciones (user_id, fecha_inicio) VALUES (%s, %s)",
                (conversacion.user_id, conversacion.fecha_inicio)
            )
            conn.commit()
            return {"resultado": "Conversación ingresada"}
        except mysql.connector.Error as err:
            conn.rollback()
            raise HTTPException(status_code=500, detail="Error al insertar conversación")
        finally:
            conn.close()

    def obtener_conversacion(self, conversacion_id: int):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM conversaciones WHERE id = %s", (conversacion_id,))
            result = cursor.fetchone()

            if result:
                return {
                    'id': result[0],
                    'user_id': result[1],
                    'fecha_inicio': result[2],
                }
            else:
                raise HTTPException(status_code=404, detail="Conversación no encontrada")
        except mysql.connector.Error as err:
            raise HTTPException(status_code=500, detail="Error al obtener conversación")
        finally:
            conn.close()

    def obtener_conversaciones(self):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM conversaciones")
            result = cursor.fetchall()
            return [
                {
                    'id': data[0],
                    'user_id': data[1],
                    'fecha_inicio': data[2],
                }
                for data in result
            ]
        except mysql.connector.Error as err:
            raise HTTPException(status_code=500, detail="Error al obtener conversaciones")
        finally:
            conn.close()

    def actualizar_conversacion(self, conversacion_id: int, conversacion: Conversacion):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE conversaciones SET user_id=%s, fecha_inicio=%s WHERE id=%s",
                (conversacion.user_id, conversacion.fecha_inicio, conversacion_id)
            )
            conn.commit()
            if cursor.rowcount == 0:
                raise HTTPException(status_code=404, detail="Conversación no encontrada")
            return {"resultado": "Conversación actualizada"}
        except mysql.connector.Error as err:
            conn.rollback()
            raise HTTPException(status_code=500, detail="Error al actualizar conversación")
        finally:
            conn.close()

    def eliminar_conversacion(self, conversacion_id: int):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("DELETE FROM conversaciones WHERE id = %s", (conversacion_id,))
            conn.commit()
            if cursor.rowcount == 0:
                raise HTTPException(status_code=404, detail="Conversación no encontrada")
            return {"resultado": "Conversación eliminada"}
        except mysql.connector.Error as err:
            conn.rollback()
            raise HTTPException(status_code=500, detail="Error al eliminar conversación")
        finally:
            conn.close()
