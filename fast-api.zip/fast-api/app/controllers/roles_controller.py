import mysql.connector
from fastapi import HTTPException
from config.db_config import get_db_connection
from models.roles_model import Roles

class RolesController:

    def crear_rol(self, rol: Roles):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO roles (nombre, descripcion, estado) VALUES (%s, %s, %s)",
                (rol.nombre, rol.descripcion, rol.estado)
            )
            conn.commit()
            return {"resultado": "Rol creado"}
        except mysql.connector.Error as err:
            conn.rollback()
            raise HTTPException(status_code=500, detail="Error al crear rol")
        finally:
            conn.close()

    def obtener_rol(self, rol_id: int):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM roles WHERE id = %s", (rol_id,))
            result = cursor.fetchone()

            if result:
                return {
                    'id': result[0],
                    'nombre': result[1],
                    'descripcion': result[2],
                    'estado': result[3],
                    'fecha_creacion': result[4],
                    'fecha_actualizacion': result[5],
                }
            else:
                raise HTTPException(status_code=404, detail="Rol no encontrado")
        except mysql.connector.Error as err:
            raise HTTPException(status_code=500, detail="Error al obtener rol")
        finally:
            conn.close()

    def obtener_roles_todos(self):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM roles")
            result = cursor.fetchall()
            return [
                {
                    'id': data[0],
                    'nombre': data[1],
                    'descripcion': data[2],
                    'estado': data[3],
                    'fecha_creacion': data[4],
                    'fecha_actualizacion': data[5],
                }
                for data in result
            ]
        except mysql.connector.Error as err:
            raise HTTPException(status_code=500, detail="Error al obtener roles")
        finally:
            conn.close()

    def actualizar_rol(self, rol_id: int, rol: Roles):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE roles SET nombre=%s, descripcion=%s, estado=%s WHERE id=%s",
                (rol.nombre, rol.descripcion, rol.estado, rol_id)
            )
            conn.commit()
            if cursor.rowcount == 0:
                raise HTTPException(status_code=404, detail="Rol no encontrado")
            return {"resultado": "Rol actualizado"}
        except mysql.connector.Error as err:
            conn.rollback()
            raise HTTPException(status_code=500, detail="Error al actualizar rol")
        finally:
            conn.close()

    def eliminar_rol(self, rol_id: int):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("DELETE FROM roles WHERE id = %s", (rol_id,))
            conn.commit()
            if cursor.rowcount == 0:
                raise HTTPException(status_code=404, detail="Rol no encontrado")
            return {"resultado": "Rol eliminado"}
        except mysql.connector.Error as err:
            conn.rollback()
            raise HTTPException(status_code=500, detail="Error al eliminar rol")
        finally:
            conn.close()
