import mysql.connector
from fastapi import HTTPException
from config.db_config import get_db_connection
from models.mensajes_model import Mensaje
from fastapi.encoders import jsonable_encoder

class MensajesController:

    def crear_mensaje(self, mensaje: Mensaje):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO mensajes (conversacion_id, remitente, mensaje) VALUES (%s, %s, %s)",
                (mensaje.conversacion_id, mensaje.remitente, mensaje.mensaje)
            )
            conn.commit()
            return {"resultado": "Mensaje ingresado"}
        except mysql.connector.Error as err:
            conn.rollback()
            raise HTTPException(status_code=500, detail="Error al insertar mensaje")
        finally:
            conn.close()

    def obtener_mensaje(self, mensaje_id: int):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM mensajes WHERE id = %s", (mensaje_id,))
            result = cursor.fetchone()

            if result:
                return {
                    'id': result[0],
                    'conversacion_id': result[1],
                    'remitente': result[2],
                    'mensaje': result[3],
                    'fecha': result[4],
                }
            else:
                raise HTTPException(status_code=404, detail="Mensaje no encontrado")
        except mysql.connector.Error as err:
            raise HTTPException(status_code=500, detail="Error al obtener mensaje")
        finally:
            conn.close()

    def obtener_mensajes(self):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM mensajes")
            result = cursor.fetchall()
            return [
                {
                    'id': data[0],
                    'conversacion_id': data[1],
                    'remitente': data[2],
                    'mensaje': data[3],
                    'fecha': data[4],
                }
                for data in result
            ]
        except mysql.connector.Error as err:
            raise HTTPException(status_code=500, detail="Error al obtener mensajes")
        finally:
            conn.close()

    def actualizar_mensaje(self, mensaje_id: int, mensaje: Mensaje):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE mensajes SET conversacion_id=%s, remitente=%s, mensaje=%s WHERE id=%s",
                (mensaje.conversacion_id, mensaje.remitente, mensaje.mensaje, mensaje_id)
            )
            conn.commit()
            if cursor.rowcount == 0:
                raise HTTPException(status_code=404, detail="Mensaje no encontrado")
            return {"resultado": "Mensaje actualizado"}
        except mysql.connector.Error as err:
            conn.rollback()
            raise HTTPException(status_code=500, detail="Error al actualizar mensaje")
        finally:
            conn.close()

    def eliminar_mensaje(self, mensaje_id: int):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("DELETE FROM mensajes WHERE id = %s", (mensaje_id,))
            conn.commit()
            if cursor.rowcount == 0:
                raise HTTPException(status_code=404, detail="Mensaje no encontrado")
            return {"resultado": "Mensaje eliminado"}
        except mysql.connector.Error as err:
            conn.rollback()
            raise HTTPException(status_code=500, detail="Error al eliminar mensaje")
        finally:
            conn.close()
