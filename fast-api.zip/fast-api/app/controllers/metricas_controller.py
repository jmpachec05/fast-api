import mysql.connector
from fastapi import HTTPException
from config.db_config import get_db_connection
from models.metricas_model import Metricas
from fastapi.encoders import jsonable_encoder

class MetricasController:

    def crear_metricas(self, metricas: Metricas):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO metricas (incidencia_id, tiempo_resolucion) VALUES (%s, %s)",
                (metricas.incidencia_id, metricas.tiempo_resolucion)
            )
            conn.commit()
            return {"resultado": "Métrica ingresada"}
        except mysql.connector.Error as err:
            conn.rollback()
            raise HTTPException(status_code=500, detail="Error al insertar métrica")
        finally:
            conn.close()

    def obtener_metricas(self, metricas_id: int):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM metricas WHERE id = %s", (metricas_id,))
            result = cursor.fetchone()

            if result:
                return {
                    'id': result[0],
                    'incidencia_id': result[1],
                    'tiempo_resolucion': result[2],
                    'fecha': result[3],
                }
            else:
                raise HTTPException(status_code=404, detail="Métrica no encontrada")
        except mysql.connector.Error as err:
            raise HTTPException(status_code=500, detail="Error al obtener métrica")
        finally:
            conn.close()

    def obtener_metricas_todas(self):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM metricas")
            result = cursor.fetchall()
            return [
                {
                    'id': data[0],
                    'incidencia_id': data[1],
                    'tiempo_resolucion': data[2],
                    'fecha': data[3],
                }
                for data in result
            ]
        except mysql.connector.Error as err:
            raise HTTPException(status_code=500, detail="Error al obtener métricas")
        finally:
            conn.close()

    def actualizar_metricas(self, metricas_id: int, metricas: Metricas):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE metricas SET incidencia_id=%s, tiempo_resolucion=%s WHERE id=%s",
                (metricas.incidencia_id, metricas.tiempo_resolucion, metricas_id)
            )
            conn.commit()
            if cursor.rowcount == 0:
                raise HTTPException(status_code=404, detail="Métrica no encontrada")
            return {"resultado": "Métrica actualizada"}
        except mysql.connector.Error as err:
            conn.rollback()
            raise HTTPException(status_code=500, detail="Error al actualizar métrica")
        finally:
            conn.close()

    def eliminar_metricas(self, metricas_id: int):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("DELETE FROM metricas WHERE id = %s", (metricas_id,))
            conn.commit()
            if cursor.rowcount == 0:
                raise HTTPException(status_code=404, detail="Métrica no encontrada")
            return {"resultado": "Métrica eliminada"}
        except mysql.connector.Error as err:
            conn.rollback()
            raise HTTPException(status_code=500, detail="Error al eliminar métrica")
        finally:
            conn.close()
