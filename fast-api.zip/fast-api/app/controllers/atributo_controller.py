import mysql.connector
from fastapi import HTTPException
from config.db_config import get_db_connection
from models.atributo_model import Atributo  
from fastapi.encoders import jsonable_encoder

class AtributosController:
    
    def crear_atributo(self, atributo: Atributo):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO atributos (nombre, descripcion, estado) VALUES (%s, %s, %s)",
                (atributo.nombre, atributo.descripcion, atributo.estado)
            )
            conn.commit()
            return {"resultado": "Atributo ingresado"}
        except mysql.connector.Error as err:
            conn.rollback()
            raise HTTPException(status_code=500, detail=str(err))
        finally:
            conn.close()

    def obtener_atributo(self, atributo_id: int):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM atributos WHERE id = %s", (atributo_id,))
            result = cursor.fetchone()
            if result:
                return {
                    'id': result[0],
                    'nombre': result[1],
                    'descripcion': result[2],
                    'estado': result[3],
                    'fecha_creacion': result[4],
                    'fecha_actualizacion': result[5],
                }
            else:
                raise HTTPException(status_code=404, detail="Atributo no encontrado")
        except mysql.connector.Error as err:
            raise HTTPException(status_code=500, detail=str(err))
        finally:
            conn.close()

    def obtener_atributos(self):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM atributos")
            result = cursor.fetchall()
            atributos = []
            for data in result:
                atributos.append({
                    'id': data[0],
                    'nombre': data[1],
                    'descripcion': data[2],
                    'estado': data[3],
                    'fecha_creacion': data[4],
                    'fecha_actualizacion': data[5],
                })
            return {"resultado": atributos}
        except mysql.connector.Error as err:
            raise HTTPException(status_code=500, detail=str(err))
        finally:
            conn.close()

    def actualizar_atributo(self, atributo_id: int, atributo: Atributo):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE atributos SET nombre = %s, descripcion = %s, estado = %s WHERE id = %s",
                (atributo.nombre, atributo.descripcion, atributo.estado, atributo_id)
            )
            conn.commit()
            if cursor.rowcount == 0:
                raise HTTPException(status_code=404, detail="Atributo no encontrado")
            return {"resultado": "Atributo actualizado"}
        except mysql.connector.Error as err:
            conn.rollback()
            raise HTTPException(status_code=500, detail=str(err))
        finally:
            conn.close()

    def eliminar_atributo(self, atributo_id: int):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("DELETE FROM atributos WHERE id = %s", (atributo_id,))
            conn.commit()
            if cursor.rowcount == 0:
                raise HTTPException(status_code=404, detail="Atributo no encontrado")
            return {"resultado": "Atributo eliminado"}
        except mysql.connector.Error as err:
            conn.rollback()
            raise HTTPException(status_code=500, detail=str(err))
        finally:
            conn.close()
