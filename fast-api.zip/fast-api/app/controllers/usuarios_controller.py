import mysql.connector
from fastapi import HTTPException
from config.db_config import get_db_connection
from models.usuarios_model import Usuario

class UsuarioController:

    def crear_usuario(self, usuario: Usuario):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO usuarios (nombre, apellido, correo_electronico, telefono, id_rol, estado) VALUES (%s, %s, %s, %s, %s, %s)",
                (usuario.nombre, usuario.apellido, usuario.correo_electronico, usuario.telefono, usuario.id_rol, usuario.estado)
            )
            conn.commit()
            return {"resultado": "Usuario creado"}
        except mysql.connector.Error as err:
            conn.rollback()
            raise HTTPException(status_code=500, detail="Error al crear usuario")
        finally:
            conn.close()

    def obtener_usuario(self, usuario_id: int):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM usuarios WHERE id = %s", (usuario_id,))
            result = cursor.fetchone()

            if result:
                return {
                    'id': result[0],
                    'nombre': result[1],
                    'apellido': result[2],
                    'correo_electronico': result[3],
                    'telefono': result[4],
                    'id_rol': result[5],
                    'estado': result[6],
                    'fecha_creacion': result[7],
                    'fecha_actualizacion': result[8],
                }
            else:
                raise HTTPException(status_code=404, detail="Usuario no encontrado")
        except mysql.connector.Error as err:
            raise HTTPException(status_code=500, detail="Error al obtener usuario")
        finally:
            conn.close()

    def obtener_usuarios_todos(self):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM usuarios")
            result = cursor.fetchall()
            return [
                {
                    'id': data[0],
                    'nombre': data[1],
                    'apellido': data[2],
                    'correo_electronico': data[3],
                    'telefono': data[4],
                    'id_rol': data[5],
                    'estado': data[6],
                    'fecha_creacion': data[7],
                    'fecha_actualizacion': data[8],
                }
                for data in result
            ]
        except mysql.connector.Error as err:
            raise HTTPException(status_code=500, detail="Error al obtener usuarios")
        finally:
            conn.close()

    def actualizar_usuario(self, usuario_id: int, usuario: Usuario):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE usuarios SET nombre=%s, apellido=%s, correo_electronico=%s, telefono=%s, id_rol=%s, estado=%s WHERE id=%s",
                (usuario.nombre, usuario.apellido, usuario.correo_electronico, usuario.telefono, usuario.id_rol, usuario.estado, usuario_id)
            )
            conn.commit()
            if cursor.rowcount == 0:
                raise HTTPException(status_code=404, detail="Usuario no encontrado")
            return {"resultado": "Usuario actualizado"}
        except mysql.connector.Error as err:
            conn.rollback()
            raise HTTPException(status_code=500, detail="Error al actualizar usuario")
        finally:
            conn.close()

    def eliminar_usuario(self, usuario_id: int):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("DELETE FROM usuarios WHERE id = %s", (usuario_id,))
            conn.commit()
            if cursor.rowcount == 0:
                raise HTTPException(status_code=404, detail="Usuario no encontrado")
            return {"resultado": "Usuario eliminado"}
        except mysql.connector.Error as err:
            conn.rollback()
            raise HTTPException(status_code=500, detail="Error al eliminar usuario")
        finally:
            conn.close()
