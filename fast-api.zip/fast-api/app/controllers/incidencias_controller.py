import mysql.connector
from fastapi import HTTPException
from config.db_config import get_db_connection
from models.incidencias_model import Incidencia
from fastapi.encoders import jsonable_encoder

class IncidenciasController:

    def crear_incidencia(self, incidencia: Incidencia):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO incidencias (id_usuario, fecha_reporte, descripcion, estado) VALUES (%s, %s, %s, %s)",
                (incidencia.id_usuario, incidencia.fecha_reporte, incidencia.descripcion, incidencia.estado)
            )
            conn.commit()
            return {"resultado": "Incidencia ingresada"}
        except mysql.connector.Error as err:
            conn.rollback()
            raise HTTPException(status_code=500, detail="Error al insertar incidencia")
        finally:
            conn.close()

    def obtener_incidencia(self, incidencia_id: int):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM incidencias WHERE id = %s", (incidencia_id,))
            result = cursor.fetchone()

            if result:
                return {
                    'id': result[0],
                    'id_usuario': result[1],
                    'fecha_reporte': result[2],
                    'descripcion': result[3],
                    'estado': result[4],
                    'fecha_creacion': result[5],
                    'fecha_actualizacion': result[6],
                }
            else:
                raise HTTPException(status_code=404, detail="Incidencia no encontrada")
        except mysql.connector.Error as err:
            raise HTTPException(status_code=500, detail="Error al obtener incidencia")
        finally:
            conn.close()

    def obtener_incidencias(self):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM incidencias")
            result = cursor.fetchall()
            return [
                {
                    'id': data[0],
                    'id_usuario': data[1],
                    'fecha_reporte': data[2],
                    'descripcion': data[3],
                    'estado': data[4],
                    'fecha_creacion': data[5],
                    'fecha_actualizacion': data[6],
                }
                for data in result
            ]
        except mysql.connector.Error as err:
            raise HTTPException(status_code=500, detail="Error al obtener incidencias")
        finally:
            conn.close()

    def actualizar_incidencia(self, incidencia_id: int, incidencia: Incidencia):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE incidencias SET id_usuario=%s, fecha_reporte=%s, descripcion=%s, estado=%s WHERE id=%s",
                (incidencia.id_usuario, incidencia.fecha_reporte, incidencia.descripcion, incidencia.estado, incidencia_id)
            )
            conn.commit()
            if cursor.rowcount == 0:
                raise HTTPException(status_code=404, detail="Incidencia no encontrada")
            return {"resultado": "Incidencia actualizada"}
        except mysql.connector.Error as err:
            conn.rollback()
            raise HTTPException(status_code=500, detail="Error al actualizar incidencia")
        finally:
            conn.close()

    def eliminar_incidencia(self, incidencia_id: int):
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("DELETE FROM incidencias WHERE id = %s", (incidencia_id,))
            conn.commit()
            if cursor.rowcount == 0:
                raise HTTPException(status_code=404, detail="Incidencia no encontrada")
            return {"resultado": "Incidencia eliminada"}
        except mysql.connector.Error as err:
            conn.rollback()
            raise HTTPException(status_code=500, detail="Error al eliminar incidencia")
        finally:
            conn.close()
