from fastapi import APIRouter
from models.usuarios_model import Usuario
from controllers.usuarios_controller import UsuarioController

router = APIRouter()
controller = UsuarioController()

@router.post("/usuarios/", response_description="Crear usuario")
async def crear_usuario(usuario: Usuario):
    return controller.crear_usuario(usuario)

@router.get("/usuarios/{usuario_id}", response_description="Obtener usuario por ID")
async def obtener_usuario(usuario_id: int):
    return controller.obtener_usuario(usuario_id)

@router.get("/usuarios/", response_description="Obtener todos los usuarios")
async def obtener_usuarios_todos():
    return controller.obtener_usuarios_todos()

@router.put("/usuarios/{usuario_id}", response_description="Actualizar usuario")
async def actualizar_usuario(usuario_id: int, usuario: Usuario):
    return controller.actualizar_usuario(usuario_id, usuario)

@router.delete("/usuarios/{usuario_id}", response_description="Eliminar usuario")
async def eliminar_usuario(usuario_id: int):
    return controller.eliminar_usuario(usuario_id)
