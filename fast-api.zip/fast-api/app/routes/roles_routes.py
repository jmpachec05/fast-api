from fastapi import APIRouter
from models.roles_model import Roles
from controllers.roles_controller import RolesController

router = APIRouter()
controller = RolesController()

@router.post("/roles/", response_description="Crear rol")
async def crear_rol(rol: Roles):
    return controller.crear_rol(rol)

@router.get("/roles/{rol_id}", response_description="Obtener rol por ID")
async def obtener_rol(rol_id: int):
    return controller.obtener_rol(rol_id)

@router.get("/roles/", response_description="Obtener todos los roles")
async def obtener_roles_todos():
    return controller.obtener_roles_todos()

@router.put("/roles/{rol_id}", response_description="Actualizar rol")
async def actualizar_rol(rol_id: int, rol: Roles):
    return controller.actualizar_rol(rol_id, rol)

@router.delete("/roles/{rol_id}", response_description="Eliminar rol")
async def eliminar_rol(rol_id: int):
    return controller.eliminar_rol(rol_id)
