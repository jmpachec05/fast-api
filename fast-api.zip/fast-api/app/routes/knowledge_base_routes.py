from fastapi import APIRouter
from models.knowledge_base_model import KnowledgeBase
from controllers.knowledge_base_controller import KnowledgeBaseController

router = APIRouter()
controller = KnowledgeBaseController()

@router.post("/knowledge_base/", response_description="Crear artículo")
async def crear_articulo(articulo: KnowledgeBase):
    return controller.crear_articulo(articulo)

@router.get("/knowledge_base/{articulo_id}", response_description="Obtener artículo por ID")
async def obtener_articulo(articulo_id: int):
    return controller.obtener_articulo(articulo_id)

@router.get("/knowledge_base/", response_description="Obtener todos los artículos")
async def obtener_articulos():
    return controller.obtener_articulos()

@router.put("/knowledge_base/{articulo_id}", response_description="Actualizar artículo")
async def actualizar_articulo(articulo_id: int, articulo: KnowledgeBase):
    return controller.actualizar_articulo(articulo_id, articulo)

@router.delete("/knowledge_base/{articulo_id}", response_description="Eliminar artículo")
async def eliminar_articulo(articulo_id: int):
    return controller.eliminar_articulo(articulo_id)
