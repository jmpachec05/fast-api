from fastapi import APIRouter
from models.metricas_model import Metricas
from controllers.metricas_controller import MetricasController

router = APIRouter()
controller = MetricasController()

@router.post("/metricas/", response_description="Crear métrica")
async def crear_metricas(metricas: Metricas):
    return controller.crear_metricas(metricas)

@router.get("/metricas/{metricas_id}", response_description="Obtener métrica por ID")
async def obtener_metricas(metricas_id: int):
    return controller.obtener_metricas(metricas_id)

@router.get("/metricas/", response_description="Obtener todas las métricas")
async def obtener_metricas_todas():
    return controller.obtener_metricas_todas()

@router.put("/metricas/{metricas_id}", response_description="Actualizar métrica")
async def actualizar_metricas(metricas_id: int, metricas: Metricas):
    return controller.actualizar_metricas(metricas_id, metricas)

@router.delete("/metricas/{metricas_id}", response_description="Eliminar métrica")
async def eliminar_metricas(metricas_id: int):
    return controller.eliminar_metricas(metricas_id)
