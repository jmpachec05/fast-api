from fastapi import APIRouter
from models.incidencias_model import Incidencia
from controllers.incidencias_controller import IncidenciasController

router = APIRouter()
controller = IncidenciasController()

@router.post("/incidencias/", response_description="Crear incidencia")
async def crear_incidencia(incidencia: Incidencia):
    return controller.crear_incidencia(incidencia)

@router.get("/incidencias/{incidencia_id}", response_description="Obtener incidencia por ID")
async def obtener_incidencia(incidencia_id: int):
    return controller.obtener_incidencia(incidencia_id)

@router.get("/incidencias/", response_description="Obtener todas las incidencias")
async def obtener_incidencias():
    return controller.obtener_incidencias()

@router.put("/incidencias/{incidencia_id}", response_description="Actualizar incidencia")
async def actualizar_incidencia(incidencia_id: int, incidencia: Incidencia):
    return controller.actualizar_incidencia(incidencia_id, incidencia)

@router.delete("/incidencias/{incidencia_id}", response_description="Eliminar incidencia")
async def eliminar_incidencia(incidencia_id: int):
    return controller.eliminar_incidencia(incidencia_id)
