from fastapi import APIRouter
from models.conversaciones_model import Conversacion
from controllers.conversaciones_controller import ConversacionesController

router = APIRouter()
controller = ConversacionesController()

@router.post("/conversaciones/", response_description="Crear conversación")
async def crear_conversacion(conversacion: Conversacion):
    return controller.crear_conversacion(conversacion)

@router.get("/conversaciones/{conversacion_id}", response_description="Obtener conversación por ID")
async def obtener_conversacion(conversacion_id: int):
    return controller.obtener_conversacion(conversacion_id)

@router.get("/conversaciones/", response_description="Obtener todas las conversaciones")
async def obtener_conversaciones():
    return controller.obtener_conversaciones()

@router.put("/conversaciones/{conversacion_id}", response_description="Actualizar conversación")
async def actualizar_conversacion(conversacion_id: int, conversacion: Conversacion):
    return controller.actualizar_conversacion(conversacion_id, conversacion)

@router.delete("/conversaciones/{conversacion_id}", response_description="Eliminar conversación")
async def eliminar_conversacion(conversacion_id: int):
    return controller.eliminar_conversacion(conversacion_id)
