from fastapi import APIRouter
from controllers.atributo_controller import AtributosController
from models.atributo_model import Atributo

router = APIRouter()
atributos_controller = AtributosController()

@router.post("/atributos/", response_model=dict)
def crear_atributo(atributo: Atributo):
    return atributos_controller.crear_atributo(atributo)

@router.get("/atributos/", response_model=dict)
def obtener_atributos():
    return atributos_controller.obtener_atributos()

@router.get("/atributos/{atributo_id}", response_model=dict)
def obtener_atributo(atributo_id: int):
    return atributos_controller.obtener_atributo(atributo_id)

@router.put("/atributos/{atributo_id}", response_model=dict)
def actualizar_atributo(atributo_id: int, atributo: Atributo):
    return atributos_controller.actualizar_atributo(atributo_id, atributo)

@router.delete("/atributos/{atributo_id}", response_model=dict)
def eliminar_atributo(atributo_id: int):
    return atributos_controller.eliminar_atributo(atributo_id)
