from fastapi import APIRouter
from models.respuestas_model import Respuestas
from controllers.respuestas_controller import RespuestasController

router = APIRouter()
controller = RespuestasController()

@router.post("/respuestas/", response_description="Crear respuesta")
async def crear_respuesta(respuesta: Respuestas):
    return controller.crear_respuesta(respuesta)

@router.get("/respuestas/{respuesta_id}", response_description="Obtener respuesta por ID")
async def obtener_respuesta(respuesta_id: int):
    return controller.obtener_respuesta(respuesta_id)

@router.get("/respuestas/", response_description="Obtener todas las respuestas")
async def obtener_respuestas_todas():
    return controller.obtener_respuestas_todas()

@router.put("/respuestas/{respuesta_id}", response_description="Actualizar respuesta")
async def actualizar_respuesta(respuesta_id: int, respuesta: Respuestas):
    return controller.actualizar_respuesta(respuesta_id, respuesta)

@router.delete("/respuestas/{respuesta_id}", response_description="Eliminar respuesta")
async def eliminar_respuesta(respuesta_id: int):
    return controller.eliminar_respuesta(respuesta_id)
