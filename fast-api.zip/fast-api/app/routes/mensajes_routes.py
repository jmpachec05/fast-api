from fastapi import APIRouter
from models.mensajes_model import Mensaje
from controllers.mensajes_controller import MensajesController

router = APIRouter()
controller = MensajesController()

@router.post("/mensajes/", response_description="Crear mensaje")
async def crear_mensaje(mensaje: Mensaje):
    return controller.crear_mensaje(mensaje)

@router.get("/mensajes/{mensaje_id}", response_description="Obtener mensaje por ID")
async def obtener_mensaje(mensaje_id: int):
    return controller.obtener_mensaje(mensaje_id)

@router.get("/mensajes/", response_description="Obtener todos los mensajes")
async def obtener_mensajes():
    return controller.obtener_mensajes()

@router.put("/mensajes/{mensaje_id}", response_description="Actualizar mensaje")
async def actualizar_mensaje(mensaje_id: int, mensaje: Mensaje):
    return controller.actualizar_mensaje(mensaje_id, mensaje)

@router.delete("/mensajes/{mensaje_id}", response_description="Eliminar mensaje")
async def eliminar_mensaje(mensaje_id: int):
    return controller.eliminar_mensaje(mensaje_id)
