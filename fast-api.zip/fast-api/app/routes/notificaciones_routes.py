from fastapi import APIRouter
from models.notificaciones_model import Notificaciones
from controllers.notificaciones_controller import NotificacionesController

router = APIRouter()
controller = NotificacionesController()

@router.post("/notificaciones/", response_description="Crear notificación")
async def crear_notificacion(notificacion: Notificaciones):
    return controller.crear_notificacion(notificacion)

@router.get("/notificaciones/{notificacion_id}", response_description="Obtener notificación por ID")
async def obtener_notificacion(notificacion_id: int):
    return controller.obtener_notificacion(notificacion_id)

@router.get("/notificaciones/", response_description="Obtener todas las notificaciones")
async def obtener_notificaciones_todas():
    return controller.obtener_notificaciones_todas()

@router.put("/notificaciones/{notificacion_id}", response_description="Actualizar notificación")
async def actualizar_notificacion(notificacion_id: int, notificacion: Notificaciones):
    return controller.actualizar_notificacion(notificacion_id, notificacion)

@router.delete("/notificaciones/{notificacion_id}", response_description="Eliminar notificación")
async def eliminar_notificacion(notificacion_id: int):
    return controller.eliminar_notificacion(notificacion_id)
