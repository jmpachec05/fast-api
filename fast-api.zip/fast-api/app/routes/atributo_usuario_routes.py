from fastapi import APIRouter
from models.atributo_usuario_model import AtributoUsuario
from controllers.atributo_usuario_controller import AtributoUsuarioController

router = APIRouter()
controller = AtributoUsuarioController()

@router.post("/atributo_usuario/", response_description="Crear atributo usuario")
async def crear_atributo_usuario(atributo_usuario: AtributoUsuario):
    return controller.crear_atributo_usuario(atributo_usuario)

@router.get("/atributo_usuario/{atributo_usuario_id}", response_description="Obtener atributo usuario por ID")
async def obtener_atributo_usuario(atributo_usuario_id: int):
    return controller.obtener_atributo_usuario(atributo_usuario_id)

@router.get("/atributo_usuario/", response_description="Obtener todos los atributos usuarios")
async def obtener_atributos_usuarios():
    return controller.obtener_atributos_usuarios()

@router.put("/atributo_usuario/{atributo_usuario_id}", response_description="Actualizar atributo usuario")
async def actualizar_atributo_usuario(atributo_usuario_id: int, atributo_usuario: AtributoUsuario):
    return controller.actualizar_atributo_usuario(atributo_usuario_id, atributo_usuario)

@router.delete("/atributo_usuario/{atributo_usuario_id}", response_description="Eliminar atributo usuario")
async def eliminar_atributo_usuario(atributo_usuario_id: int):
    return controller.eliminar_atributo_usuario(atributo_usuario_id)
