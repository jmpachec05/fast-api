from fastapi import APIRouter
from models.permisos_model import Permisos
from controllers.permisos_controller import PermisosController

router = APIRouter()
controller = PermisosController()

@router.post("/permisos/", response_description="Crear permiso")
async def crear_permiso(permiso: Permisos):
    return controller.crear_permiso(permiso)

@router.get("/permisos/{permiso_id}", response_description="Obtener permiso por ID")
async def obtener_permiso(permiso_id: int):
    return controller.obtener_permiso(permiso_id)

@router.get("/permisos/", response_description="Obtener todos los permisos")
async def obtener_permisos_todos():
    return controller.obtener_permisos_todos()

@router.put("/permisos/{permiso_id}", response_description="Actualizar permiso")
async def actualizar_permiso(permiso_id: int, permiso: Permisos):
    return controller.actualizar_permiso(permiso_id, permiso)

@router.delete("/permisos/{permiso_id}", response_description="Eliminar permiso")
async def eliminar_permiso(permiso_id: int):
    return controller.eliminar_permiso(permiso_id)
