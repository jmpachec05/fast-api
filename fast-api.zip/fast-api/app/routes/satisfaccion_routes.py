from fastapi import APIRouter
from models.satisfaccion_model import Satisfaccion
from controllers.satisfaccion_controller import SatisfaccionController

router = APIRouter()
controller = SatisfaccionController()

@router.post("/satisfaccion/", response_description="Crear satisfacción")
async def crear_satisfaccion(satisfaccion: Satisfaccion):
    return controller.crear_satisfaccion(satisfaccion)

@router.get("/satisfaccion/{satisfaccion_id}", response_description="Obtener satisfacción por ID")
async def obtener_satisfaccion(satisfaccion_id: int):
    return controller.obtener_satisfaccion(satisfaccion_id)

@router.get("/satisfaccion/", response_description="Obtener todas las satisfacciones")
async def obtener_satisfacciones_todas():
    return controller.obtener_satisfacciones_todas()

@router.put("/satisfaccion/{satisfaccion_id}", response_description="Actualizar satisfacción")
async def actualizar_satisfaccion(satisfaccion_id: int, satisfaccion: Satisfaccion):
    return controller.actualizar_satisfaccion(satisfaccion_id, satisfaccion)

@router.delete("/satisfaccion/{satisfaccion_id}", response_description="Eliminar satisfacción")
async def eliminar_satisfaccion(satisfaccion_id: int):
    return controller.eliminar_satisfaccion(satisfaccion_id)
