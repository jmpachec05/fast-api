from pydantic import BaseModel, conint
from typing import Optional

class Satisfaccion(BaseModel):
    id: Optional[int] = None
    user_id: Optional[int] = None
    incidencia_id: Optional[int] = None
    calificacion: conint(ge=1, le=5)  # Debe estar entre 1 y 5
    feedback: Optional[str] = None

    class Config:
        orm_mode = True
