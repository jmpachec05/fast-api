from pydantic import BaseModel
from typing import Optional

class Permisos(BaseModel):
    id: Optional[int] = None
    rol_id: Optional[int] = None
    permiso: Optional[str] = None

    class Config:
        orm_mode = True
