from pydantic import BaseModel
from typing import Optional
from datetime import datetime
from enum import Enum

class RemitenteEnum(str, Enum):
    usuario = 'usuario'
    bot = 'bot'

class Mensaje(BaseModel):
    id: Optional[int] = None
    conversacion_id: Optional[int] = None
    remitente: RemitenteEnum
    mensaje: Optional[str] = None
    fecha: datetime = datetime.now()

    class Config:
        orm_mode = True
