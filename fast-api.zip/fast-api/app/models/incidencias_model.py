from pydantic import BaseModel
from typing import Optional
from datetime import date, datetime

class Incidencia(BaseModel):
    id: Optional[int] = None
    id_usuario: Optional[int] = None
    fecha_reporte: Optional[date] = None
    descripcion: Optional[str] = None
    estado: Optional[int] = 1
    fecha_creacion: datetime = datetime.now()
    fecha_actualizacion: datetime = datetime.now()

    class Config:
        orm_mode = True
