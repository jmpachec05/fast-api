from pydantic import BaseModel, EmailStr
from typing import Optional
from datetime import datetime

class Usuario(BaseModel):
    id: Optional[int] = None
    nombre: str
    apellido: str
    correo_electronico: EmailStr
    telefono: Optional[str] = None
    id_rol: Optional[int] = None
    estado: int = 1  # 1 para activo, 0 para inactivo
    fecha_creacion: Optional[datetime] = None
    fecha_actualizacion: Optional[datetime] = None

    class Config:
        orm_mode = True
