from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class KnowledgeBase(BaseModel):
    id: Optional[int] = None
    titulo: Optional[str] = None
    contenido: Optional[str] = None
    categoria: Optional[str] = None
    fecha_publicacion: datetime = datetime.now()

    class Config:
        orm_mode = True
