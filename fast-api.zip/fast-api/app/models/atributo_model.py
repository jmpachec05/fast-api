from pydantic import BaseModel
from typing import Optional

class Atributo(BaseModel):
    id: Optional[int] = None
    nombre: str
    descripcion: Optional[str] = None
    estado: Optional[int] = 1  # Valor por defecto
    fecha_creacion: Optional[str] = None  
    fecha_actualizacion: Optional[str] = None

    class Config:
        orm_mode = True
