from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class Metricas(BaseModel):
    id: Optional[int] = None
    incidencia_id: Optional[int] = None
    tiempo_resolucion: Optional[int] = None
    fecha: datetime = datetime.now()

    class Config:
        orm_mode = True
