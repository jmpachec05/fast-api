from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class Roles(BaseModel):
    id: Optional[int] = None
    nombre: str
    descripcion: Optional[str] = None
    estado: Optional[int] = 1
    fecha_creacion: Optional[datetime] = None
    fecha_actualizacion: Optional[datetime] = None

    class Config:
        orm_mode = True
