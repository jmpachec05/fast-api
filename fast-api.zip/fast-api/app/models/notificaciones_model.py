from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class Notificaciones(BaseModel):
    id: Optional[int] = None
    user_id: Optional[int] = None
    incidencia_id: Optional[int] = None
    mensaje: Optional[str] = None
    leido: Optional[bool] = False
    fecha: datetime = datetime.now()

    class Config:
        orm_mode = True
