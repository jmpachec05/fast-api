from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class AtributoUsuario(BaseModel):
    id: Optional[int] = None
    id_usuario: Optional[int] = None
    id_atributo: Optional[int] = None
    valor_atributo: Optional[str] = None
    estado: int = 1
    fecha_creacion: datetime = datetime.now()
    fecha_actualizacion: datetime = datetime.now()

    class Config:
        orm_mode = True
