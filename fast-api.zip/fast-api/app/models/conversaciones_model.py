from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class Conversacion(BaseModel):
    id: Optional[int] = None
    user_id: Optional[int] = None
    fecha_inicio: datetime = datetime.now()

    class Config:
        orm_mode = True
