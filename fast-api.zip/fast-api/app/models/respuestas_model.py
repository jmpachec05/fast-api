from pydantic import BaseModel
from typing import Optional

class Respuestas(BaseModel):
    id: Optional[int] = None
    pregunta_clave: Optional[str] = None
    respuesta: Optional[str] = None

    class Config:
        orm_mode = True
